#ifndef INC_METTLE_BASIC_SUITE_HPP
#define INC_METTLE_BASIC_SUITE_HPP

#include "suite/attributes.hpp"
#include "suite/compiled_suite.hpp"
#include "suite/make_suite.hpp"
#include "suite/global_suite.hpp"

#endif
