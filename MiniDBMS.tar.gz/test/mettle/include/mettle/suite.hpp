#ifndef INC_METTLE_SUITE_HPP
#define INC_METTLE_SUITE_HPP

#include "basic_suite.hpp"
#include "glue.hpp"

#endif
