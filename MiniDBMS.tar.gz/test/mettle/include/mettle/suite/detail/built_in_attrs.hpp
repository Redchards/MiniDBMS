#ifndef INC_METTLE_SUITE_DETAIL_BUILT_IN_ATTRS_HPP
#define INC_METTLE_SUITE_DETAIL_BUILT_IN_ATTRS_HPP

#include "../attributes.hpp"

namespace mettle {

bool_attr skip("skip", test_action::skip);

} // namespace mettle

#endif
